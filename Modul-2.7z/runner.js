const knopka = document.querySelector('.plus');  // получил кнопку
const textarea = document.querySelector('.textarea'); // и текстовое поле

let lists = [];               // создал пустой массив для работы

knopka.addEventListener('click', (event) => {
    let newLi = document.createElement('li');            // создаю лишку и добавляю начинку
    newLi.innerHTML = `<form class="formText"><textarea class="textarea" rows="1" cols="20"></textarea><button class="reset" type="button">&#215;</button></form>`;
    document.querySelector('.textareaUl').append(newLi);
});

const buttonDelete = document.querySelector('.reset');    // поймал кнопку удаления элемента списка

buttonDelete.addEventListener('click', (event) => {
    event.target.parentElement.remove();
});

const buttonSort = document.querySelector('.sortBlack');   // поймал кнопку сортировки

buttonSort.addEventListener('click', (event) => {
    let textareaArray = document.querySelectorAll('.textarea'); // получил значения из списков
    lists = Array.from(textareaArray);          // преобразовал в массив эти данные (из нод листа)

    lists.sort((a, b) => {                  //   функция сортировки по значниям велью (т.к. эо текстАрея)
        if (a.value > b.value) {             
            return 1;
        } else if (a.value < b.value) {
            return -1;
        }
        return 0;
    });
    //  console.log(lists.map(a => a.value), '<----');

    let textareaUl = document.querySelector('.textareaUl');    // поймал список для добавления отсортированных данных
    lists.forEach((el) => {                                   // залил отсортированные значения сразу в родителя li
        textareaUl.appendChild(el.parentElement.parentElement);
    });

});
